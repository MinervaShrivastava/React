const Header = () =>(
    
        <h1>Welcome</h1>
    
);

export default Header;