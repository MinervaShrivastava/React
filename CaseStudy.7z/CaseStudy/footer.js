const Footer = () => (
    <div>
        <h4>Made by Minerva Shrivastava</h4>
    </div>
);
export default Footer;