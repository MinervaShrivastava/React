import Header from './header';
import Footer from './footer';
import MainContent from './main_content';

const ShoppingApp = () =>(
    <div>
        <Header/>
        <MainContent/>
        <Footer/>
    </div>
);

export default ShoppingApp;