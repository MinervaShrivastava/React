const MainContent = () =>{
    return(
        <div>
            login here 
        </div>
    );

};

export default MainContent;